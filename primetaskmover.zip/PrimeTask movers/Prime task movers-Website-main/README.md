## This website has been made in a simple HTML, CSS & JS file. 
 # It is a packers and movers company located in Abu Dhabi, Saudi Arab.

# The tools which has been used:
  a.For responsiveness used the Bootstrap,     
  b.For animation used the javascript library AOS (Animation on Scroll),       
  c.For track user behavior used the Google Anlytics tool.
